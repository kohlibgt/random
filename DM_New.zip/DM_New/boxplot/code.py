import csv

def read_csv(filepath):
    with open(filepath, 'r') as file:
        reader = csv.reader(file)
        
        # Read header and data, assuming one column for CGPA
        try:
            header = next(reader)
        except StopIteration:
            raise ValueError("The CSV file is empty or improperly formatted.")
        
        rows = []
        for row in reader:
            if row and row[0].replace('.', '', 1).isdigit():  # Ensure row[0] is numeric
                rows.append([float(row[0])])
            else:
                print(f"Skipping non-numeric or empty row: {row}")
        
    return header, rows

def five_number_summary(data):
    data = sorted(data)
    n = len(data)
    
    if n == 0:
        print("No data available to compute the summary.")
        return

    min_val = data[0]
    max_val = data[-1]
    median = (data[n // 2 - 1] + data[n // 2]) / 2 if n % 2 == 0 else data[n // 2]
    
    lower_half = data[:n // 2]
    upper_half = data[(n + 1) // 2:] if n % 2 != 0 else data[n // 2:]

    q1 = (lower_half[len(lower_half) // 2 - 1] + lower_half[len(lower_half) // 2]) / 2 if len(lower_half) % 2 == 0 else lower_half[len(lower_half) // 2]
    q3 = (upper_half[len(upper_half) // 2 - 1] + upper_half[len(upper_half) // 2]) / 2 if len(upper_half) % 2 == 0 else upper_half[len(upper_half) // 2]

    iqr = q3 - q1
    lower_bound = max(0, q1 - 1.5 * iqr)
    upper_bound = q3 + 1.5 * iqr

    outliers = [val for val in data if val < lower_bound or val > upper_bound]

    print("Min:", min_val)
    print("Q1:", q1)
    print("Median:", median)
    print("Q3:", q3)
    print("Max:", max_val)
    print("Upper Bound:", upper_bound)
    print("Lower Bound:", lower_bound)
    print("Interquartile Range:", iqr)
    print("Outliers:", outliers)
    print()

def process_csv(file_path):
    header, rows = read_csv(file_path)
    columns = list(zip(*rows))

    for idx, col in enumerate(columns):
        print(f"Summary for Column '{header[idx]}':")
        five_number_summary(col)

# Input file path
input_file = 'C:/Users/Omkar/OneDrive/Desktop/DM_New/experiment8/code.csv'
process_csv(input_file)
