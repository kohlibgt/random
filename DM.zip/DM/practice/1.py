import csv

def read_csv(filepath):
    with open(filepath, 'r') as file:
        reader = csv.reader(file)
        header = next(reader)
        rows = [[float(value) for value in row] for row in reader]
    return header, rows
          

def min_max(header,rows):
    columns = list(zip(*rows))
    print(header,columns)
    new_min=int(input("print new min limit"))
    new_max=int(input("print new max limit"))
    print(new_min,new_max)
    normalized_col = []

    for i,value in enumerate(columns):
        new_value = value-100
        normalized_col.append(new_value)
    
    print(normalized_col)

        


def process_csv(file_path,output_filepath):
    header,rows = read_csv(file_path)
    min_max(header,rows)


file_path="C:/Users/nalaw/OneDrive/Desktop/Normalization/practice/data.csv"
output_filepath="C:/Users/nalaw/OneDrive/Desktop/Normalization/practice/output.csv"
process_csv(file_path,output_filepath)