import csv

data = {}
row_totals = {}
col_totals = {}

with open('C:/Users/Omkar/OneDrive/Desktop/DM/tdweight/ip.csv') as file:
    reader = csv.reader(file)
    header = next(reader) 
    
    for line in reader:
        region, company, sales = line
        sales = int(sales)

        if region not in data:
            data[region] = {}
        data[region][company] = sales

        # Track row and column totals
        row_totals[region] = row_totals.get(region, 0) + sales
        col_totals[company] = col_totals.get(company, 0) + sales


total_sum = sum(row_totals.values())

# Print header row
print("Region\\Brand  |  Nokia (Count, t-weight, d-weight)  |  Apple (Count, t-weight, d-weight)  |  Total")
print("-" * 80)


for region, row_total in row_totals.items():
    row_data = [region]
    for company, col_total in col_totals.items():
        value = data.get(region, {}).get(company, 0)
        t_weight = f"{(value / row_total) * 100:.2f}%" if row_total else "0%"
        d_weight = f"{(value / col_total) * 100:.2f}%" if col_total else "0%"
        row_data.append(f"{value} ({t_weight}, {d_weight})")

  
    row_data.append(f"{row_total} (100%, {(row_total / total_sum) * 100:.2f}%)")
    print(" | ".join(row_data))

# Print the totals row
total_row = ["Total"]
for company, col_total in col_totals.items():
    t_weight = f"{(col_total / total_sum) * 100:.2f}%"
    total_row.append(f"{col_total} ({t_weight}, 100%)")
total_row.append(f"{total_sum} (100%, 100%)")
print(" | ".join(total_row))