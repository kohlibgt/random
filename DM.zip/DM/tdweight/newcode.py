import csv

# Initialize data structures
data = {}
row_totals = {}
col_totals = {}

# Read data from CSV
with open('C:/Users/Omkar/OneDrive/Desktop/DM/tdweight/newip.csv') as file:
    reader = csv.reader(file)
    header = next(reader)  # Skip the header row

    # Read each row and update data, row totals, and column totals
    for line in reader:
        # Skip rows that don't have exactly 4 values
        if len(line) != 4:
            print(f"Skipping invalid row: {line}")
            continue

        company, tv, mobile, tablet = line
        try:
            tv, mobile, tablet = int(tv), int(mobile), int(tablet)
        except ValueError:
            print(f"Invalid numeric values in row: {line}")
            continue

        # Initialize company data if not present
        if company not in data:
            data[company] = {'tv': 0, 'mobile': 0, 'tablet': 0}

        data[company]['tv'] += tv
        data[company]['mobile'] += mobile
        data[company]['tablet'] += tablet

        # Update row totals
        row_totals[company] = row_totals.get(company, 0) + tv + mobile + tablet

        # Update column totals
        col_totals['tv'] = col_totals.get('tv', 0) + tv
        col_totals['mobile'] = col_totals.get('mobile', 0) + mobile
        col_totals['tablet'] = col_totals.get('tablet', 0) + tablet

# Calculate total sum of all sales
total_sum = sum(row_totals.values())

# Print header row
print("Company | tv (t-weight, d-weight) | mobile (t-weight, d-weight) | tablet (t-weight, d-weight) | Total")
print("-" * 80)

# Calculate t-weight and d-weight for each company and each product category
for company, row_total in row_totals.items():
    row_data = [company]
    for product, col_total in col_totals.items():
        value = data[company].get(product, 0)

        # Calculate t-weight (percentage of row total)
        t_weight = f"{(value / row_total) * 100:.2f}%" if row_total else "0%"

        # Calculate d-weight (percentage of column total)
        d_weight = f"{(value / col_total) * 100:.2f}%" if col_total else "0%"

        row_data.append(f"{value} ({t_weight}, {d_weight})")

    # Add total row data
    row_data.append(f"{row_total} (100%, {(row_total / total_sum) * 100:.2f}%)")
    print(" | ".join(row_data))

# Print the totals row
total_row = ["Total"]
for product, col_total in col_totals.items():
    t_weight = f"{(col_total / total_sum) * 100:.2f}%"
    total_row.append(f"{col_total} ({t_weight}, 100%)")
total_row.append(f"{total_sum} (100%, 100%)")
print(" | ".join(total_row))
