import csv

def read_csv(file_name):
    data = []
    with open(file_name, mode='r') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            data.append(row)
    return data

def mean(values):
    return sum(values) / len(values)

def pearson_correlation(x, y):
    n = len(x)
    mean_x = mean(x)
    mean_y = mean(y)
    
    numerator = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n))
    denominator_x = sum((x[i] - mean_x) ** 2 for i in range(n))
    denominator_y = sum((y[i] - mean_y) ** 2 for i in range(n))
    
    denominator = (denominator_x * denominator_y) ** 0.5
    if denominator == 0:
        return 0
    return numerator / denominator

def linear_regression(x, y):
    n = len(x)
    mean_x = mean(x)
    mean_y = mean(y)
    
    # Calculate slope (m) and intercept (b)
    numerator = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n))
    denominator = sum((x[i] - mean_x) ** 2 for i in range(n))
    
    if denominator == 0:
        raise ValueError("Cannot compute linear regression with zero variance in x.")
    
    m = numerator / denominator
    b = mean_y - m * mean_x
    
    return m, b

def save_results(correlation, slope, intercept, output_file):
    with open(output_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Correlation Coefficient", correlation])
        writer.writerow(["Linear Regression Equation", f"y = {slope}x + {intercept}"])

# Main program
file_name = 'C:/Users/Omkar/OneDrive/Desktop/DM/newcorrelation/new.csv'  # Update with your CSV file path
output_file = 'C:/Users/Omkar/OneDrive/Desktop/DM/newcorrelation/output.csv'

data = read_csv(file_name)

# Assuming 'age' and 'income' are columns in your CSV
x = [float(row['age']) for row in data]
y = [float(row['income']) for row in data]

# Calculate correlation and linear regression
correlation = pearson_correlation(x, y)
slope, intercept = linear_regression(x, y)

# Save results to CSV
save_results(correlation, slope, intercept, output_file)

print(f"Pearson Correlation Coefficient: {correlation}")
print(f"Linear Regression Equation: y = {slope}x + {intercept}")
print(f"Results saved to {output_file}")
