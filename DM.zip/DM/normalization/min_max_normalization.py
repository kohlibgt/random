import csv

def read_csv(filepath):
    with open(filepath, 'r') as file:
        reader = csv.reader(file)
        header = next(reader)
        rows = [[float(value) for value in row] for row in reader]
    return header, rows

def min_max_normalize(data, header):
    columns = list(zip(*data))
    normalized_columns = []

    for i, col in enumerate(columns):

        print(f"Processing column: {header[i]}")

        new_min = float(input(f"Enter the new minimum value for '{header[i]}' column: "))  
        
        new_max = float(input(f"Enter the new maximum value for '{header[i]}' column: "))  

        normalized_col = []
        min_val = min(col)
        max_val = max(col)

        for val in col:
            if max_val != min_val:
                normalized_value = round(new_min + (val - min_val) * (new_max - new_min) / (max_val - min_val), 3)
            else:
                normalized_value = new_min
                
            normalized_col.append(normalized_value)
        
        normalized_columns.append(normalized_col)

    normalized_data = list(zip(*normalized_columns))
    return normalized_data



def write_csv(filepath, header, rows):
    with open(filepath, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(header)
        writer.writerows(rows)

def process_csv(input_filepath, output_filepath):
    header, rows = read_csv(input_filepath)
    normalized_rows = min_max_normalize(rows, header)
    write_csv(output_filepath, header, normalized_rows)


input_file = 'C:/Users/Omkar/OneDrive/Desktop/DM/normalization/ip.csv'
output_file = 'C:/Users/Omkar/OneDrive/Desktop/DM/normalization/output_min_max.csv'

process_csv(input_file, output_file)
