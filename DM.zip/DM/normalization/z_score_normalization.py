import csv
import math

def read_csv(filepath):
    with open(filepath, 'r') as file:
        reader = csv.reader(file)
        header = next(reader)
        rows = [[float(value) for value in row] for row in reader]
    return header, rows

def z_score_normalize(data):
    columns = list(zip(*data))
    normalized_columns = []

    for col in columns:
        
        mean = sum(col) / len(col)
        
        variance_sum = sum((x - mean) ** 2 for x in col)
        stddev = math.sqrt(variance_sum / len(col))
    
        normalized_col = [(round((x - mean) / stddev, 3) if stddev != 0 else 0) for x in col]
        
        normalized_columns.append(normalized_col)

    normalized_data = list(zip(*normalized_columns))
    return normalized_data

def write_csv(filepath, header, rows):
    with open(filepath, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(header)
        writer.writerows(rows)

def process_csv(input_filepath, output_filepath):
    header, rows = read_csv(input_filepath)
    normalized_rows = z_score_normalize(rows)
    write_csv(output_filepath, header, normalized_rows)

input_file = 'C:/Users/Omkar/OneDrive/Desktop/DM/normalization/ip.csv'
output_file ='C:/Users/Omkar/OneDrive/Desktop/DM/normalization/output_z_score.csv'

process_csv(input_file, output_file)
