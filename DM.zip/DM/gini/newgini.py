import csv

def read_csv(file_name):
    data = []
    with open(file_name, mode='r') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            data.append(row)
    return data

def gini_index(data, attr, target_attr):
    # Frequency dictionary for attribute values
    val_freq = {}
    gini_values = {}
    
    # Count occurrences of each value in the attribute
    for record in data:
        if record[attr] in val_freq:
            val_freq[record[attr]] += 1.0
        else:
            val_freq[record[attr]] = 1.0

    # Calculate Gini index for each subclass of the attribute
    for val in val_freq.keys():
        subset_data = [record for record in data if record[attr] == val]
        subset_gini = 1.0
        val_prob = len(subset_data) / len(data)
        
        # Frequency dictionary for target attribute in the subset
        target_freq = {}
        for record in subset_data:
            if record[target_attr] in target_freq:
                target_freq[record[target_attr]] += 1.0
            else:
                target_freq[record[target_attr]] = 1.0
        
        # Calculate the Gini index for the subset based on target class distribution
        for freq in target_freq.values():
            prob = freq / len(subset_data)
            subset_gini -= prob ** 2  # Gini formula: 1 - Σ(prob^2)
        
        gini_values[val] = subset_gini
    
    return gini_values

file_name = 'C:/Users/Omkar/OneDrive/Desktop/DM/gini/newip.csv'
data = read_csv(file_name)

target_attribute = input("Enter the target attribute (e.g., 'Play'): ")
attribute = 'Colour'  # Single attribute to analyze

print(f"\nCalculating Gini Index for subclasses of '{attribute}' with respect to target '{target_attribute}':")
gini_values = gini_index(data, attribute, target_attribute)

for val, gini in gini_values.items():
    print(f"Gini Index for {attribute}='{val}': {gini:.4f}")

# Determine the "best" split based on minimum Gini index
best_split = min(gini_values, key=gini_values.get)
print(f"\nBest split is '{attribute}={best_split}' with the lowest Gini Index of {gini_values[best_split]:.4f}")
